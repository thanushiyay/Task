import { Component, OnInit, Output } from '@angular/core';
import{HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private  http:HttpClient) { }
  public addresses: any[] = [{
    address: '',
    street: '',
    city: '',
    country: ''
  }];
  ngOnInit(): void {
  }

  addAddress() {
    this.addresses.push({
      address: '',
      street: '',
      city: '',
      country: ''
    });
  }


  removeAddress(i: number) {
    this.addresses.splice(i, 1);
  }



  logValue() {
    console.log(this.addresses);
  }
}
